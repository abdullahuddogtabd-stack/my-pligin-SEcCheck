<?php
/**
 * Plugin Name: UBD WordPress Security Auditor
 * Plugin URI:  https://uddogtabd.com/
 * Description: নিরাপদ read-only security audit: updates, HTTPS, users, configuration, permissions, core integrity এবং uploads-এ executable files পরীক্ষা করে।
 * Version:     1.0.0
 * Author:      UBD
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ubd-security-auditor
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'UBD_SA_VERSION', '1.0.0' );
define( 'UBD_SA_FILE', __FILE__ );
define( 'UBD_SA_DIR', plugin_dir_path( __FILE__ ) );
define( 'UBD_SA_URL', plugin_dir_url( __FILE__ ) );

require_once UBD_SA_DIR . 'includes/class-ubd-security-auditor.php';

register_activation_hook( __FILE__, array( 'UBD_Security_Auditor', 'activate' ) );

UBD_Security_Auditor::instance();
