<?php
/**
 * Main plugin class.
 *
 * @package UBD_Security_Auditor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class UBD_Security_Auditor {
	const OPTION_LAST_SCAN = 'ubd_sa_last_scan';
	const NONCE_SCAN       = 'ubd_sa_run_scan';
	const NONCE_EXPORT     = 'ubd_sa_export';

	/** @var UBD_Security_Auditor|null */
	private static $instance = null;

	/**
	 * Singleton.
	 *
	 * @return UBD_Security_Auditor
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_ubd_sa_run_scan', array( $this, 'handle_scan' ) );
		add_action( 'admin_post_ubd_sa_export', array( $this, 'handle_export' ) );
		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widget' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( UBD_SA_FILE ), array( $this, 'plugin_action_links' ) );
	}

	/**
	 * Activation defaults.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( false === get_option( self::OPTION_LAST_SCAN, false ) ) {
			add_option( self::OPTION_LAST_SCAN, array(), '', false );
		}
	}

	/**
	 * Add settings link.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$url = admin_url( 'tools.php?page=ubd-security-auditor' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">Security Scan</a>' );
		return $links;
	}

	/**
	 * Register Tools menu.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_management_page(
			'UBD Security Auditor',
			'UBD Security Audit',
			'manage_options',
			'ubd-security-auditor',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Load admin CSS only on this plugin page.
	 *
	 * @param string $hook_suffix Current admin hook.
	 * @return void
	 */
	public function enqueue_assets( $hook_suffix ) {
		if ( 'tools_page_ubd-security-auditor' !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'ubd-security-auditor',
			UBD_SA_URL . 'assets/admin.css',
			array(),
			UBD_SA_VERSION
		);
	}

	/**
	 * Register dashboard summary widget.
	 *
	 * @return void
	 */
	public function register_dashboard_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'ubd_sa_dashboard_widget',
			'UBD Security Audit',
			array( $this, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render dashboard widget.
	 *
	 * @return void
	 */
	public function render_dashboard_widget() {
		$scan = get_option( self::OPTION_LAST_SCAN, array() );

		if ( empty( $scan['completed_at'] ) ) {
			echo '<p>এখনও security scan চালানো হয়নি।</p>';
		} else {
			$score = isset( $scan['score'] ) ? absint( $scan['score'] ) : 0;
			echo '<p><strong>শেষ Score: ' . esc_html( $score ) . '/100</strong></p>';
			echo '<p>শেষ Scan: ' . esc_html( $scan['completed_at'] ) . '</p>';
		}

		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'tools.php?page=ubd-security-auditor' ) ) . '">রিপোর্ট দেখুন</a></p>';
	}

	/**
	 * Handle scan form.
	 *
	 * @return void
	 */
	public function handle_scan() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to run this scan.', 'ubd-security-auditor' ) );
		}

		check_admin_referer( self::NONCE_SCAN );

		@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		$scan = $this->run_scan();
		update_option( self::OPTION_LAST_SCAN, $scan, false );

		$redirect = add_query_arg(
			array(
				'page'    => 'ubd-security-auditor',
				'scanned' => '1',
			),
			admin_url( 'tools.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Export the last report as JSON.
	 *
	 * @return void
	 */
	public function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to export this report.', 'ubd-security-auditor' ) );
		}

		check_admin_referer( self::NONCE_EXPORT );

		$scan = get_option( self::OPTION_LAST_SCAN, array() );
		if ( empty( $scan ) ) {
			wp_die( esc_html__( 'No scan report is available.', 'ubd-security-auditor' ) );
		}

		$filename = 'ubd-security-report-' . gmdate( 'Y-m-d-His' ) . '.json';
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
		echo wp_json_encode( $scan, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	/**
	 * Render plugin page.
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$scan = get_option( self::OPTION_LAST_SCAN, array() );
		?>
		<div class="wrap ubd-sa-wrap">
			<h1>UBD WordPress Security Auditor</h1>
			<p class="description">এই plugin শুধু পরীক্ষা করে এবং রিপোর্ট দেয়। কোনো file, user, setting বা database নিজে থেকে পরিবর্তন করে না।</p>

			<?php if ( isset( $_GET['scanned'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['scanned'] ) ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success is-dismissible"><p>Security scan সম্পন্ন হয়েছে।</p></div>
			<?php endif; ?>

			<div class="ubd-sa-toolbar">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="ubd_sa_run_scan">
					<?php wp_nonce_field( self::NONCE_SCAN ); ?>
					<?php submit_button( 'নতুন Security Scan চালান', 'primary', 'submit', false ); ?>
				</form>

				<?php if ( ! empty( $scan ) ) : ?>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ubd_sa_export' ), self::NONCE_EXPORT ) ); ?>">JSON Report Download</a>
				<?php endif; ?>
			</div>

			<?php if ( empty( $scan['results'] ) ) : ?>
				<div class="ubd-sa-empty">
					<h2>প্রথম Scan চালান</h2>
					<p>Scan চলাকালে WordPress core checksum এবং update তথ্যের জন্য wordpress.org-এ request যেতে পারে। বড় uploads folder হলে scan কিছুটা server resource ব্যবহার করবে।</p>
				</div>
			<?php else : ?>
				<?php $this->render_summary( $scan ); ?>
				<?php $this->render_results( $scan['results'] ); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render report summary.
	 *
	 * @param array $scan Scan data.
	 * @return void
	 */
	private function render_summary( $scan ) {
		$score   = isset( $scan['score'] ) ? absint( $scan['score'] ) : 0;
		$counts  = isset( $scan['counts'] ) && is_array( $scan['counts'] ) ? $scan['counts'] : array();
		$classes = $score >= 85 ? 'good' : ( $score >= 65 ? 'warning' : 'critical' );
		?>
		<div class="ubd-sa-summary">
			<div class="ubd-sa-score ubd-sa-score-<?php echo esc_attr( $classes ); ?>">
				<span class="ubd-sa-score-number"><?php echo esc_html( $score ); ?></span>
				<span>/100</span>
				<small>Approximate Security Score</small>
			</div>
			<div class="ubd-sa-meta">
				<p><strong>Site:</strong> <?php echo esc_html( isset( $scan['site_url'] ) ? $scan['site_url'] : '' ); ?></p>
				<p><strong>Scan time:</strong> <?php echo esc_html( isset( $scan['completed_at'] ) ? $scan['completed_at'] : '' ); ?></p>
				<p>
					<span class="ubd-sa-pill pass">Pass: <?php echo esc_html( isset( $counts['pass'] ) ? absint( $counts['pass'] ) : 0 ); ?></span>
					<span class="ubd-sa-pill warning">Warning: <?php echo esc_html( isset( $counts['warning'] ) ? absint( $counts['warning'] ) : 0 ); ?></span>
					<span class="ubd-sa-pill critical">Critical: <?php echo esc_html( isset( $counts['critical'] ) ? absint( $counts['critical'] ) : 0 ); ?></span>
					<span class="ubd-sa-pill info">Info: <?php echo esc_html( isset( $counts['info'] ) ? absint( $counts['info'] ) : 0 ); ?></span>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render all checks.
	 *
	 * @param array $results Check results.
	 * @return void
	 */
	private function render_results( $results ) {
		$order = array( 'critical', 'warning', 'pass', 'info' );

		foreach ( $order as $status ) {
			$items = array_values(
				array_filter(
					$results,
					function ( $item ) use ( $status ) {
						return isset( $item['status'] ) && $status === $item['status'];
					}
				)
			);

			if ( empty( $items ) ) {
				continue;
			}

			echo '<h2 class="ubd-sa-section-title">' . esc_html( ucfirst( $status ) ) . ' Checks</h2>';
			echo '<div class="ubd-sa-grid">';
			foreach ( $items as $item ) {
				$this->render_result_card( $item );
			}
			echo '</div>';
		}
	}

	/**
	 * Render one result card.
	 *
	 * @param array $item Result.
	 * @return void
	 */
	private function render_result_card( $item ) {
		$status = isset( $item['status'] ) ? sanitize_key( $item['status'] ) : 'info';
		?>
		<div class="ubd-sa-card ubd-sa-card-<?php echo esc_attr( $status ); ?>">
			<div class="ubd-sa-card-head">
				<span class="ubd-sa-status"><?php echo esc_html( strtoupper( $status ) ); ?></span>
				<h3><?php echo esc_html( isset( $item['title'] ) ? $item['title'] : '' ); ?></h3>
			</div>
			<p><?php echo esc_html( isset( $item['details'] ) ? $item['details'] : '' ); ?></p>
			<?php if ( ! empty( $item['recommendation'] ) ) : ?>
				<p class="ubd-sa-recommendation"><strong>করণীয়:</strong> <?php echo esc_html( $item['recommendation'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Run all audit checks.
	 *
	 * @return array
	 */
	private function run_scan() {
		$results = array();

		$this->refresh_update_data();

		$checks = array(
			'check_https',
			'check_http_headers',
			'check_wordpress_updates',
			'check_plugin_updates',
			'check_inactive_plugins',
			'check_theme_updates',
			'check_inactive_themes',
			'check_php_version',
			'check_debug_configuration',
			'check_file_editor',
			'check_ssl_admin',
			'check_registration',
			'check_admin_users',
			'check_database_prefix',
			'check_security_keys',
			'check_file_permissions',
			'check_security_plugin',
			'check_two_factor_plugin',
			'check_backup_plugin',
			'check_uploads_php_protection',
			'check_uploads_executables',
			'check_core_integrity',
		);

		foreach ( $checks as $method ) {
			try {
				$result = $this->{$method}();
				if ( isset( $result[0] ) && is_array( $result[0] ) ) {
					$results = array_merge( $results, $result );
				} else {
					$results[] = $result;
				}
			} catch ( Throwable $exception ) {
				$results[] = $this->result(
					'info',
					'একটি Check সম্পন্ন হয়নি',
					$method . ': ' . $exception->getMessage(),
					'Hosting error log পরীক্ষা করুন অথবা plugin developer-কে report দিন.'
				);
			}
		}

		$counts = array(
			'pass'     => 0,
			'warning'  => 0,
			'critical' => 0,
			'info'     => 0,
		);

		foreach ( $results as $result ) {
			if ( isset( $result['status'], $counts[ $result['status'] ] ) ) {
				$counts[ $result['status'] ]++;
			}
		}

		$score = max( 0, 100 - ( $counts['critical'] * 12 ) - ( $counts['warning'] * 5 ) );

		return array(
			'plugin_version' => UBD_SA_VERSION,
			'site_url'       => home_url( '/' ),
			'wordpress'      => get_bloginfo( 'version' ),
			'php'            => PHP_VERSION,
			'completed_at'   => current_time( 'mysql' ),
			'score'          => $score,
			'counts'         => $counts,
			'results'        => $results,
		);
	}

	/**
	 * Safely refresh cached update information.
	 *
	 * @return void
	 */
	private function refresh_update_data() {
		require_once ABSPATH . 'wp-admin/includes/update.php';

		if ( function_exists( 'wp_version_check' ) ) {
			wp_version_check();
		}
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
		}
		if ( function_exists( 'wp_update_themes' ) ) {
			wp_update_themes();
		}
	}

	/**
	 * Result helper.
	 *
	 * @param string $status Status.
	 * @param string $title Title.
	 * @param string $details Details.
	 * @param string $recommendation Recommendation.
	 * @return array
	 */
	private function result( $status, $title, $details, $recommendation = '' ) {
		$allowed = array( 'pass', 'warning', 'critical', 'info' );
		if ( ! in_array( $status, $allowed, true ) ) {
			$status = 'info';
		}

		return array(
			'status'         => $status,
			'title'          => $title,
			'details'        => $details,
			'recommendation' => $recommendation,
		);
	}

	/** @return array */
	private function check_https() {
		$home_https = 0 === stripos( home_url( '/' ), 'https://' );
		$site_https = 0 === stripos( site_url( '/' ), 'https://' );

		if ( $home_https && $site_https ) {
			return $this->result( 'pass', 'HTTPS configuration', 'WordPress Address এবং Site Address—দুটিই HTTPS ব্যবহার করছে.' );
		}

		return $this->result(
			'critical',
			'HTTPS configuration',
			'WordPress-এর এক বা একাধিক প্রধান URL এখনও HTTP ব্যবহার করছে.',
			'SSL certificate ঠিক করে Settings → General থেকে WordPress Address এবং Site Address-এ https:// ব্যবহার করুন.'
		);
	}

	/** @return array */
	private function check_http_headers() {
		$response = wp_remote_head(
			home_url( '/' ),
			array(
				'timeout'     => 10,
				'redirection' => 5,
				'sslverify'   => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->result( 'info', 'HTTP security headers', 'Website response পরীক্ষা করা যায়নি: ' . $response->get_error_message() );
		}

		$missing = array();
		$hsts    = wp_remote_retrieve_header( $response, 'strict-transport-security' );
		$nosniff = wp_remote_retrieve_header( $response, 'x-content-type-options' );
		$xframe  = wp_remote_retrieve_header( $response, 'x-frame-options' );
		$csp     = wp_remote_retrieve_header( $response, 'content-security-policy' );
		$refpol  = wp_remote_retrieve_header( $response, 'referrer-policy' );

		if ( 0 === stripos( home_url( '/' ), 'https://' ) && empty( $hsts ) ) {
			$missing[] = 'HSTS';
		}
		if ( empty( $nosniff ) ) {
			$missing[] = 'X-Content-Type-Options';
		}
		if ( empty( $xframe ) && ( empty( $csp ) || false === stripos( $csp, 'frame-ancestors' ) ) ) {
			$missing[] = 'clickjacking protection';
		}
		if ( empty( $refpol ) ) {
			$missing[] = 'Referrer-Policy';
		}

		if ( empty( $missing ) ) {
			return $this->result( 'pass', 'HTTP security headers', 'প্রধান security headers response-এ পাওয়া গেছে.' );
		}

		return $this->result(
			'warning',
			'HTTP security headers',
			'অনুপস্থিত বা শনাক্ত হয়নি: ' . implode( ', ', $missing ) . '.',
			'Hosting/Cloudflare level-এ headers যোগ করুন। CSP যোগ করার আগে staging site-এ পরীক্ষা করুন.'
		);
	}

	/** @return array */
	private function check_wordpress_updates() {
		$updates = get_site_transient( 'update_core' );
		$found   = array();

		if ( isset( $updates->updates ) && is_array( $updates->updates ) ) {
			foreach ( $updates->updates as $update ) {
				if ( isset( $update->response ) && 'upgrade' === $update->response && ! empty( $update->current ) ) {
					$found[] = $update->current;
				}
			}
		}

		if ( empty( $found ) ) {
			return $this->result( 'pass', 'WordPress core update', 'WordPress core-এর pending update পাওয়া যায়নি.' );
		}

		return $this->result( 'critical', 'WordPress core update', 'Available version: ' . implode( ', ', array_unique( $found ) ) . '.', 'সম্পূর্ণ backup নিয়ে WordPress core update করুন.' );
	}

	/** @return array */
	private function check_plugin_updates() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		$updates = function_exists( 'get_plugin_updates' ) ? get_plugin_updates() : array();

		if ( empty( $updates ) ) {
			return $this->result( 'pass', 'Plugin updates', 'কোনো pending plugin update পাওয়া যায়নি.' );
		}

		$names = array();
		foreach ( $updates as $data ) {
			$names[] = isset( $data->Name ) ? $data->Name : 'Unknown plugin';
		}

		return $this->result( 'critical', 'Plugin updates', count( $names ) . 'টি plugin update দরকার: ' . implode( ', ', array_slice( $names, 0, 10 ) ) . ( count( $names ) > 10 ? '…' : '' ), 'Backup ও staging test-এর পর plugins update করুন.' );
	}

	/** @return array */
	private function check_inactive_plugins() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$all      = get_plugins();
		$active   = $this->get_active_plugin_files();
		$inactive = array_diff( array_keys( $all ), $active );

		if ( empty( $inactive ) ) {
			return $this->result( 'pass', 'Inactive plugins', 'কোনো inactive plugin পাওয়া যায়নি.' );
		}

		$names = array();
		foreach ( $inactive as $file ) {
			$names[] = isset( $all[ $file ]['Name'] ) ? $all[ $file ]['Name'] : $file;
		}

		return $this->result( 'warning', 'Inactive plugins', count( $names ) . 'টি inactive plugin আছে: ' . implode( ', ', array_slice( $names, 0, 10 ) ) . ( count( $names ) > 10 ? '…' : '' ), 'যেগুলো প্রয়োজন নেই সেগুলো backup নেওয়ার পর delete করুন.' );
	}

	/** @return array */
	private function check_theme_updates() {
		require_once ABSPATH . 'wp-admin/includes/update.php';
		$updates = function_exists( 'get_theme_updates' ) ? get_theme_updates() : array();

		if ( empty( $updates ) ) {
			return $this->result( 'pass', 'Theme updates', 'কোনো pending theme update পাওয়া যায়নি.' );
		}

		$names = array();
		foreach ( $updates as $theme ) {
			$names[] = $theme->get( 'Name' );
		}

		return $this->result( 'critical', 'Theme updates', count( $names ) . 'টি theme update দরকার: ' . implode( ', ', array_slice( $names, 0, 10 ) ) . '.', 'Backup ও staging test-এর পর themes update করুন.' );
	}

	/** @return array */
	private function check_inactive_themes() {
		$themes       = wp_get_themes();
		$active_theme = wp_get_theme();
		$allowed      = array( $active_theme->get_stylesheet(), $active_theme->get_template() );
		$inactive     = array();

		foreach ( $themes as $stylesheet => $theme ) {
			if ( ! in_array( $stylesheet, $allowed, true ) ) {
				$inactive[] = $theme->get( 'Name' );
			}
		}

		if ( count( $inactive ) <= 1 ) {
			return $this->result( 'pass', 'Inactive themes', 'Active theme-এর বাইরে সর্বোচ্চ একটি fallback theme আছে.' );
		}

		return $this->result( 'warning', 'Inactive themes', count( $inactive ) . 'টি inactive theme আছে: ' . implode( ', ', array_slice( $inactive, 0, 10 ) ) . '.', 'Active theme এবং একটি current default fallback theme রেখে বাকিগুলো delete করুন.' );
	}

	/** @return array */
	private function check_php_version() {
		if ( version_compare( PHP_VERSION, '8.3', '>=' ) ) {
			return $this->result( 'pass', 'PHP version', 'PHP ' . PHP_VERSION . ' ব্যবহার হচ্ছে; WordPress-এর বর্তমান recommended level পূরণ করছে.' );
		}

		if ( version_compare( PHP_VERSION, '8.1', '>=' ) ) {
			return $this->result( 'warning', 'PHP version', 'PHP ' . PHP_VERSION . ' ব্যবহার হচ্ছে; PHP 8.3 বা নতুন version recommended.', 'আগে staging site-এ theme/plugin compatibility পরীক্ষা করে hosting থেকে PHP upgrade করুন.' );
		}

		return $this->result( 'critical', 'PHP version', 'পুরোনো PHP ' . PHP_VERSION . ' ব্যবহার হচ্ছে.', 'Backup ও compatibility test-এর পর supported PHP version-এ upgrade করুন.' );
	}

	/** @return array */
	private function check_debug_configuration() {
		$debug         = defined( 'WP_DEBUG' ) && WP_DEBUG;
		$debug_display = defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY;

		if ( ! $debug && ! $debug_display ) {
			return $this->result( 'pass', 'Debug information exposure', 'WP_DEBUG এবং public debug display বন্ধ আছে.' );
		}

		return $this->result( 'critical', 'Debug information exposure', 'Production website-এ debug output চালু থাকতে পারে.', 'wp-config.php-এ WP_DEBUG এবং WP_DEBUG_DISPLAY false করুন; প্রয়োজন হলে WP_DEBUG_LOG সাময়িকভাবে ব্যবহার করুন.' );
	}

	/** @return array */
	private function check_file_editor() {
		if ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ) {
			return $this->result( 'pass', 'Dashboard file editor', 'Plugin/Theme file editor disabled আছে.' );
		}

		return $this->result( 'warning', 'Dashboard file editor', 'DISALLOW_FILE_EDIT চালু পাওয়া যায়নি.', "wp-config.php-এ define( 'DISALLOW_FILE_EDIT', true ); যোগ করুন." );
	}

	/** @return array */
	private function check_ssl_admin() {
		if ( defined( 'FORCE_SSL_ADMIN' ) && FORCE_SSL_ADMIN ) {
			return $this->result( 'pass', 'Secure admin sessions', 'FORCE_SSL_ADMIN enabled আছে.' );
		}

		if ( 0 === stripos( site_url( '/' ), 'https://' ) ) {
			return $this->result( 'warning', 'Secure admin sessions', 'Site HTTPS হলেও FORCE_SSL_ADMIN explicitly enabled নয়.', "SSL ঠিকভাবে কাজ করলে wp-config.php-এ define( 'FORCE_SSL_ADMIN', true ); যোগ করুন." );
		}

		return $this->result( 'critical', 'Secure admin sessions', 'Admin login HTTPS enforce করা যাচ্ছে না কারণ site URL HTTPS নয়.', 'আগে SSL/HTTPS setup ঠিক করুন.' );
	}

	/** @return array */
	private function check_registration() {
		$open         = (bool) get_option( 'users_can_register' );
		$default_role = (string) get_option( 'default_role', 'subscriber' );

		if ( 'administrator' === $default_role ) {
			return $this->result( 'critical', 'User registration', 'নতুন user-এর default role Administrator সেট করা আছে.', 'Settings → General থেকে New User Default Role অবিলম্বে Subscriber করুন.' );
		}

		if ( $open ) {
			return $this->result( 'warning', 'User registration', 'Public registration enabled; default role: ' . $default_role . '.', 'Membership প্রয়োজন না হলে Settings → General থেকে Anyone can register বন্ধ করুন.' );
		}

		return $this->result( 'pass', 'User registration', 'Public user registration বন্ধ আছে.' );
	}

	/** @return array */
	private function check_admin_users() {
		$admins = get_users( array( 'role' => 'administrator' ) );
		$risky  = array( 'admin', 'administrator', 'root', 'demo', 'test' );
		$found  = array();
		$names  = array();

		foreach ( $admins as $admin ) {
			$login   = (string) $admin->user_login;
			$names[] = $login;
			if ( in_array( strtolower( $login ), $risky, true ) ) {
				$found[] = $login;
			}
		}

		if ( ! empty( $found ) ) {
			return $this->result( 'critical', 'Administrator accounts', 'সহজে অনুমানযোগ্য admin username পাওয়া গেছে: ' . implode( ', ', $found ) . '.', 'নতুন unique Administrator account তৈরি করে পুরোনো risky account-এর content transfer করে accountটি remove করুন.' );
		}

		if ( count( $admins ) > 3 ) {
			return $this->result( 'warning', 'Administrator accounts', count( $admins ) . 'টি Administrator account আছে: ' . implode( ', ', $names ) . '.', 'যাদের full access প্রয়োজন নেই তাদের Editor/Shop Manager-এর মতো least-privilege role দিন.' );
		}

		return $this->result( 'pass', 'Administrator accounts', count( $admins ) . 'টি Administrator account পাওয়া গেছে: ' . implode( ', ', $names ) . '.' );
	}

	/** @return array */
	private function check_database_prefix() {
		global $wpdb;
		$prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '';

		if ( 'wp_' !== $prefix && '' !== $prefix ) {
			return $this->result( 'pass', 'Database table prefix', 'Default wp_ prefix ব্যবহার হচ্ছে না (' . $prefix . ').' );
		}

		return $this->result( 'info', 'Database table prefix', 'Default wp_ prefix ব্যবহার হচ্ছে। এটি একা vulnerability নয় এবং পরিবর্তন করলেই site secure হয় না.', 'নতুন installation-এ custom prefix ব্যবহার করা যায়; live site-এ শুধু prefix বদলাতে গিয়ে database নষ্ট করবেন না.' );
	}

	/** @return array */
	private function check_security_keys() {
		$constants = array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' );
		$values    = array();
		$invalid   = array();

		foreach ( $constants as $name ) {
			$value = defined( $name ) ? (string) constant( $name ) : '';
			if ( strlen( $value ) < 32 || false !== stripos( $value, 'put your unique phrase here' ) ) {
				$invalid[] = $name;
			}
			$values[] = $value;
		}

		$non_empty = array_filter( $values );
		$duplicate = count( $non_empty ) !== count( array_unique( $non_empty ) );

		if ( empty( $invalid ) && ! $duplicate ) {
			return $this->result( 'pass', 'Authentication keys and salts', 'সব WordPress security key/salt উপস্থিত এবং আলাদা মনে হচ্ছে.' );
		}

		$detail = ! empty( $invalid ) ? 'Missing/weak: ' . implode( ', ', $invalid ) . '. ' : '';
		$detail .= $duplicate ? 'একই value একাধিক key-তে পাওয়া গেছে.' : '';

		return $this->result( 'critical', 'Authentication keys and salts', trim( $detail ), 'Official WordPress secret-key service থেকে নতুন salts নিয়ে wp-config.php-এ replace করুন; এতে existing sessions logout হবে.' );
	}

	/** @return array */
	private function check_file_permissions() {
		$config = $this->find_wp_config();
		$bad    = array();
		$seen   = array();

		if ( $config && file_exists( $config ) ) {
			$perm = $this->permission_string( $config );
			$seen[] = 'wp-config.php=' . $perm;
			if ( $this->permission_is_more_open_than( $perm, '0640' ) ) {
				$bad[] = 'wp-config.php (' . $perm . ')';
			}
		}

		$paths = array(
			'wp-content' => WP_CONTENT_DIR,
			'plugins'    => WP_PLUGIN_DIR,
		);
		$uploads = wp_upload_dir();
		if ( empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) ) {
			$paths['uploads'] = $uploads['basedir'];
		}

		foreach ( $paths as $label => $path ) {
			if ( file_exists( $path ) ) {
				$perm   = $this->permission_string( $path );
				$seen[] = $label . '=' . $perm;
				if ( $this->permission_is_more_open_than( $perm, '0755' ) ) {
					$bad[] = $label . ' (' . $perm . ')';
				}
			}
		}

		if ( empty( $bad ) ) {
			return $this->result( 'pass', 'File permissions', 'Checked permissions: ' . implode( ', ', $seen ) . '.' );
		}

		return $this->result( 'critical', 'File permissions', 'অতিরিক্ত open permission পাওয়া গেছে: ' . implode( ', ', $bad ) . '.', 'সাধারণভাবে folders 0755, files 0644 এবং wp-config.php 0640/0600 ব্যবহার করুন; 0777 ব্যবহার করবেন না। Hosting ownership অনুযায়ী আগে support-এর সঙ্গে মিলিয়ে নিন.' );
	}

	/** @return array */
	private function check_security_plugin() {
		$patterns = array( 'wordfence', 'all-in-one-wp-security', 'better-wp-security', 'wp-cerber', 'sucuri-scanner', 'shield-security', 'ninjafirewall', 'malcare-security' );
		$found    = $this->find_active_plugins_by_patterns( $patterns );

		if ( ! empty( $found ) ) {
			return $this->result( 'pass', 'Security/firewall plugin', 'Active security plugin পাওয়া গেছে: ' . implode( ', ', $found ) . '.' );
		}

		return $this->result( 'warning', 'Security/firewall plugin', 'পরিচিত security/firewall plugin শনাক্ত হয়নি। এই Auditor নিজে firewall নয়.', 'একটি reputable security solution ব্যবহার করুন; একই কাজের একাধিক firewall plugin একসঙ্গে চালাবেন না.' );
	}

	/** @return array */
	private function check_two_factor_plugin() {
		$patterns = array( 'two-factor', 'wp-2fa', 'wordfence', 'better-wp-security', 'all-in-one-wp-security', 'shield-security', 'miniorange-2-factor-authentication' );
		$found    = $this->find_active_plugins_by_patterns( $patterns );

		if ( ! empty( $found ) ) {
			return $this->result( 'info', 'Two-factor authentication', '2FA-capable plugin পাওয়া গেছে: ' . implode( ', ', $found ) . '. Pluginটি প্রতিটি Administrator-এর জন্য সত্যিই enabled কিনা manual check প্রয়োজন.' );
		}

		return $this->result( 'warning', 'Two-factor authentication', '2FA-capable active plugin শনাক্ত হয়নি.', 'সব Administrator account-এ 2FA চালু করুন.' );
	}

	/** @return array */
	private function check_backup_plugin() {
		$patterns = array( 'updraftplus', 'backwpup', 'duplicator', 'wpvivid', 'all-in-one-wp-migration', 'blogvault', 'jetpack' );
		$found    = $this->find_active_plugins_by_patterns( $patterns );

		if ( ! empty( $found ) ) {
			return $this->result( 'info', 'Backup system', 'Backup-capable plugin পাওয়া গেছে: ' . implode( ', ', $found ) . '. সাম্প্রতিক off-site backup সফল হয়েছে কিনা pluginটি নিশ্চিতভাবে যাচাই করতে পারে না.' );
		}

		return $this->result( 'warning', 'Backup system', 'পরিচিত backup plugin শনাক্ত হয়নি.', 'Hosting backup থাকলেও files + database-এর নিয়মিত off-site backup রাখুন এবং restore test করুন.' );
	}

	/** @return array */
	private function check_uploads_php_protection() {
		$server = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
		if ( false === stripos( $server, 'apache' ) && false === stripos( $server, 'litespeed' ) ) {
			return $this->result( 'info', 'Uploads PHP execution protection', 'Server software: ' . ( $server ? $server : 'unknown' ) . '. .htaccess-based protection নির্ভরযোগ্যভাবে যাচাই করা যায়নি.', 'Nginx/other server হলে hosting level-এ wp-content/uploads থেকে PHP execution block আছে কিনা নিশ্চিত করুন.' );
		}

		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) ) {
			return $this->result( 'info', 'Uploads PHP execution protection', 'Uploads directory পাওয়া যায়নি.' );
		}

		$htaccess = trailingslashit( $uploads['basedir'] ) . '.htaccess';
		if ( ! is_readable( $htaccess ) ) {
			return $this->result( 'warning', 'Uploads PHP execution protection', 'uploads/.htaccess protection file পাওয়া যায়নি বা readable নয়.', 'Apache/LiteSpeed হলে uploads folder-এ PHP execution deny rule যোগ করুন এবং upload/forms পরীক্ষা করুন.' );
		}

		$content = (string) file_get_contents( $htaccess );
		$php_rule = preg_match( '/<FilesMatch[^>]*(?:php|phtml|phar)[^>]*>/i', $content ) || preg_match( '/RewriteRule[^\r\n]*(?:php|phtml|phar)[^\r\n]*\[F/i', $content );
		$deny     = preg_match( '/Require\s+all\s+denied/i', $content ) || preg_match( '/deny\s+from\s+all/i', $content ) || preg_match( '/\[F(?:,|\])/i', $content );

		if ( $php_rule && $deny ) {
			return $this->result( 'pass', 'Uploads PHP execution protection', 'uploads/.htaccess-এ PHP execution deny rule পাওয়া গেছে.' );
		}

		return $this->result( 'warning', 'Uploads PHP execution protection', 'uploads/.htaccess আছে, কিন্তু স্পষ্ট PHP deny rule শনাক্ত হয়নি.', 'Rule manually review করুন; ভুল .htaccess পুরো site ভাঙতে পারে, তাই backup ও test ছাড়া পরিবর্তন করবেন না.' );
	}

	/** @return array */
	private function check_uploads_executables() {
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) || ! is_dir( $uploads['basedir'] ) ) {
			return $this->result( 'info', 'Executable files in uploads', 'Uploads directory scan করা যায়নি.' );
		}

		$findings = array();
		$scanned  = 0;
		$limit    = 20000;
		$base     = wp_normalize_path( $uploads['basedir'] );

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $uploads['basedir'], FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);

			foreach ( $iterator as $file ) {
				if ( $scanned >= $limit || count( $findings ) >= 50 ) {
					break;
				}
				$scanned++;
				if ( ! $file->isFile() || $file->isLink() ) {
					continue;
				}

				$name = strtolower( $file->getFilename() );
				if ( preg_match( '/\.(php\d*|phtml|phar|phps)$/i', $name ) || preg_match( '/\.php\.[a-z0-9]+$/i', $name ) ) {
					$path       = wp_normalize_path( $file->getPathname() );
					$findings[] = ltrim( str_replace( $base, '', $path ), '/' );
				}
			}
		} catch ( UnexpectedValueException $exception ) {
			return $this->result( 'info', 'Executable files in uploads', 'Uploads scan error: ' . $exception->getMessage() );
		}

		if ( empty( $findings ) ) {
			$detail = 'প্রথম ' . number_format_i18n( $scanned ) . 'টি uploads file scan করে executable PHP-type file পাওয়া যায়নি.';
			if ( $scanned >= $limit ) {
				$detail .= ' Scan safety limit-এ থেমেছে.';
			}
			return $this->result( 'pass', 'Executable files in uploads', $detail );
		}

		return $this->result( 'critical', 'Executable files in uploads', count( $findings ) . 'টি সন্দেহজনক executable/double-extension file পাওয়া গেছে: ' . implode( ', ', array_slice( $findings, 0, 20 ) ) . ( count( $findings ) > 20 ? '…' : '' ), 'File delete করার আগে backup নিন, file content ও origin পরীক্ষা করুন, তারপর full malware investigation করুন.' );
	}

	/** @return array */
	private function check_core_integrity() {
		global $wp_version;
		require_once ABSPATH . 'wp-admin/includes/update.php';

		if ( ! function_exists( 'get_core_checksums' ) ) {
			return $this->result( 'info', 'WordPress core integrity', 'Core checksum function পাওয়া যায়নি.' );
		}

		$locale    = get_locale();
		$checksums = get_core_checksums( $wp_version, $locale );
		if ( ! is_array( $checksums ) ) {
			$checksums = get_core_checksums( $wp_version, 'en_US' );
		}
		if ( ! is_array( $checksums ) || empty( $checksums ) ) {
			return $this->result( 'info', 'WordPress core integrity', 'wordpress.org থেকে core checksums পাওয়া যায়নি; network/version/locale কারণে হতে পারে.' );
		}

		$modified = array();
		$missing  = array();
		foreach ( $checksums as $relative => $expected_md5 ) {
			$path = ABSPATH . $relative;
			if ( ! file_exists( $path ) ) {
				$missing[] = $relative;
				continue;
			}
			if ( is_file( $path ) && md5_file( $path ) !== $expected_md5 ) {
				$modified[] = $relative;
			}
		}

		$unexpected = $this->find_unexpected_core_executables( array_keys( $checksums ) );

		if ( empty( $modified ) && empty( $unexpected ) && empty( $missing ) ) {
			return $this->result( 'pass', 'WordPress core integrity', 'Core files official checksums-এর সঙ্গে মিলেছে এবং wp-admin/wp-includes-এ unexpected executable file পাওয়া যায়নি.' );
		}

		$parts = array();
		if ( ! empty( $modified ) ) {
			$parts[] = 'Modified: ' . implode( ', ', array_slice( $modified, 0, 12 ) ) . ( count( $modified ) > 12 ? '…' : '' );
		}
		if ( ! empty( $unexpected ) ) {
			$parts[] = 'Unexpected executable: ' . implode( ', ', array_slice( $unexpected, 0, 12 ) ) . ( count( $unexpected ) > 12 ? '…' : '' );
		}
		if ( ! empty( $missing ) ) {
			$parts[] = 'Missing: ' . implode( ', ', array_slice( $missing, 0, 8 ) ) . ( count( $missing ) > 8 ? '…' : '' );
		}

		$status = ( ! empty( $modified ) || ! empty( $unexpected ) ) ? 'critical' : 'warning';
		return $this->result( $status, 'WordPress core integrity', implode( ' | ', $parts ), 'প্রথমে full backup নিন। তারপর official WordPress package দিয়ে core reinstall/replace করুন; wp-content এবং wp-config.php overwrite করবেন না। Unexpected files আলাদাভাবে malware review করুন.' );
	}

	/**
	 * Find unexpected executable files inside wp-admin and wp-includes.
	 *
	 * @param array $expected_files Checksum file paths.
	 * @return array
	 */
	private function find_unexpected_core_executables( $expected_files ) {
		$expected = array_fill_keys( array_map( 'wp_normalize_path', $expected_files ), true );
		$found    = array();
		$dirs     = array( 'wp-admin', 'wp-includes' );

		foreach ( $dirs as $dir ) {
			$absolute = ABSPATH . $dir;
			if ( ! is_dir( $absolute ) ) {
				continue;
			}

			try {
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $absolute, FilesystemIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::LEAVES_ONLY
				);
				foreach ( $iterator as $file ) {
					if ( count( $found ) >= 50 ) {
						break 2;
					}
					if ( ! $file->isFile() || $file->isLink() ) {
						continue;
					}
					if ( ! preg_match( '/\.(php\d*|phtml|phar|phps)$/i', $file->getFilename() ) ) {
						continue;
					}
					$relative = ltrim( str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( $file->getPathname() ) ), '/' );
					if ( ! isset( $expected[ $relative ] ) ) {
						$found[] = $relative;
					}
				}
			} catch ( UnexpectedValueException $exception ) {
				continue;
			}
		}

		return $found;
	}

	/**
	 * Get active plugin files, including network-active plugins.
	 *
	 * @return array
	 */
	private function get_active_plugin_files() {
		$active = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$network = array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) );
			$active  = array_merge( $active, $network );
		}
		return array_values( array_unique( $active ) );
	}

	/**
	 * Find active plugin display names by slug patterns.
	 *
	 * @param array $patterns Slug fragments.
	 * @return array
	 */
	private function find_active_plugins_by_patterns( $patterns ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$all    = get_plugins();
		$active = $this->get_active_plugin_files();
		$found  = array();

		foreach ( $active as $file ) {
			$haystack = strtolower( $file );
			foreach ( $patterns as $pattern ) {
				if ( false !== strpos( $haystack, strtolower( $pattern ) ) ) {
					$found[] = isset( $all[ $file ]['Name'] ) ? $all[ $file ]['Name'] : $file;
					break;
				}
			}
		}

		return array_values( array_unique( $found ) );
	}

	/**
	 * Locate wp-config.php.
	 *
	 * @return string|false
	 */
	private function find_wp_config() {
		$inside = ABSPATH . 'wp-config.php';
		if ( file_exists( $inside ) ) {
			return $inside;
		}

		$above = dirname( ABSPATH ) . '/wp-config.php';
		if ( file_exists( $above ) && ! file_exists( dirname( ABSPATH ) . '/wp-settings.php' ) ) {
			return $above;
		}

		return false;
	}

	/**
	 * Get four-digit permission string.
	 *
	 * @param string $path Filesystem path.
	 * @return string
	 */
	private function permission_string( $path ) {
		$perms = @fileperms( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( false === $perms ) {
			return 'unknown';
		}
		return substr( sprintf( '%o', $perms ), -4 );
	}

	/**
	 * Compare octal permissions.
	 *
	 * @param string $actual Actual mode.
	 * @param string $maximum Maximum recommended mode.
	 * @return bool
	 */
	private function permission_is_more_open_than( $actual, $maximum ) {
		if ( 'unknown' === $actual || ! preg_match( '/^[0-7]{4}$/', $actual ) ) {
			return false;
		}
		return intval( $actual, 8 ) > intval( $maximum, 8 );
	}
}
