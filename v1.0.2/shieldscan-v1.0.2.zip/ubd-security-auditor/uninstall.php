<?php
/**
 * Uninstall cleanup.
 *
 * @package UBD_Security_Auditor
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'ubd_sa_last_scan' );
