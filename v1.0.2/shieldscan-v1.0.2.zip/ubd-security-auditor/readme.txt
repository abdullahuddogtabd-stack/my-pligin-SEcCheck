=== ShieldScan ===
Contributors: ubd
Tags: security, audit, malware check, integrity, hardening
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later

Read-only WordPress security audit for updates, HTTPS, administrators, configuration, permissions, core integrity and uploads executable files.

== Description ==

ShieldScan creates a security report inside Tools > ShieldScan.

It checks:

* WordPress, plugin and theme updates
* HTTPS and selected HTTP security headers
* PHP version
* Debug and wp-config security constants
* Administrator usernames and public registration
* Security keys and salts
* File/folder permissions
* Security, 2FA and backup plugin presence
* PHP execution protection in uploads on Apache/LiteSpeed
* Executable or double-extension files in uploads
* WordPress core files against official WordPress.org checksums
* Unexpected executable files in wp-admin and wp-includes
* Client-ready Executive, Detailed and Technical report versions
* Print-friendly A4 report with browser Save as PDF support
* HTML, CSV and JSON report downloads

The plugin does not delete, repair or modify files/settings. Findings require manual verification because custom hosting configurations can produce false positives.

== Installation ==

1. Upload the ZIP from Plugins > Add New > Upload Plugin.
2. Activate ShieldScan.
3. Open Tools > ShieldScan.
4. Click "নতুন Security Scan চালান".
5. Review Critical findings first and take a complete backup before making changes.

== Important ==

This plugin is an auditor, not a web application firewall and not a replacement for off-site backups or professional malware investigation.

== Changelog ==

= 1.0.2 =
* Renamed the plugin interface and report generator to ShieldScan.
* Kept existing scan data and internal settings compatible with earlier versions.

= 1.0.1 =
* Added Client Report & PDF Builder.
* Added Executive Summary, Detailed Client and Technical Full report versions.
* Added preview, A4 print/Save as PDF, HTML, CSV and JSON outputs.
* Added client name, prepared by, report title, reference, notes and confidentiality fields.

= 1.0.0 =
* Initial release.
